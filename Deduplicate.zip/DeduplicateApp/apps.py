from django.apps import AppConfig


class DeduplicateappConfig(AppConfig):
    name = 'DeduplicateApp'
